const menuBtn=document.getElementById("menuBtn"),nav=document.getElementById("nav");
menuBtn.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));
document.getElementById("quoteForm").addEventListener("submit",function(e){
  e.preventDefault();
  const name=document.getElementById("name").value.trim();
  const phone=document.getElementById("phone").value.trim();
  const product=document.getElementById("product").value;
  const message=document.getElementById("message").value.trim();
  const text=`Hello Dentcare Solutions,%0A%0AName: ${encodeURIComponent(name)}%0APhone: ${encodeURIComponent(phone)}%0AInquiry: ${encodeURIComponent(product)}%0AMessage: ${encodeURIComponent(message)}`;
  window.open(`https://wa.me/254705386720?text=${text}`,"_blank");
});